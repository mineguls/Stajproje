a=int(input("birinci sayi:"))
b=int(input("ikinci sayi:"))
islem=input("işlemi girin:")

if islem=="1":
    print("{} ile {}nin toplami {}dir.".format(a,b,a+b))
elif islem=="2":
    print("{} ile {}nin farki {}dir.".format(a,b,a-b))
elif islem=="3":
    print("{} ile {}nin çarpimi{}dir.".format(a,b,a*b))

elif islem=="4":
    print("{} ile {}nin bolumu{}dir.".format(a,b,a/b))

else :
 print("gecersiz işlem")

     