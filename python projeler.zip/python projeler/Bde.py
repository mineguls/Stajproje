a=float(input("boynuzu giriniz(m)"))
b=int(input("kilonuzu giriniz"))

BedenKitleEndeksi=b/(a*a)
print("beden kitle endeksi:",BedenKitleEndeksi)